# Performance Issues and Fixes
*DayTrader3 Financial Trading Application*

## Overview
This document provides specific fixes and code examples for performance issues identified in the DayTrader3 codebase analysis.

⚠️ **Important**: All fixes should be tested thoroughly in a development environment before production deployment.

## Issues and Solutions

### 🔴 Resource Management Memory Leaks - Critical

**Issue Description**: Unclosed resources causing memory leaks and connection exhaustion
**Impact**: Memory consumption, connection pool exhaustion, application crashes
**Risk Level**: Critical
**Effort to Fix**: Low to Medium

#### Current Code (Problematic)
```java
// ❌ Problematic: Resources not properly closed (KeySequenceBean.java)
public static synchronized Integer getNextID(Connection conn, String keyName, boolean inSession, boolean inGlobalTxn)
    throws Exception {
    PreparedStatement stmt = conn.prepareStatement(getKeyForUpdateSQL);
    stmt.setString(1, keyName);
    ResultSet rs = stmt.executeQuery();
    
    if (!rs.next()) {
        // Exception here = resources never closed!
        PreparedStatement stmt2 = conn.prepareStatement(createKeySQL);
        int keyVal = 0;
        stmt2.setString(1, keyName);
        // Manual cleanup - error prone
        stmt2.close();
        stmt.close();
    }
    // More manual cleanup...
    stmt.close();
}
```

#### Recommended Fix
```java
// ✅ Fixed: Use try-with-resources for automatic cleanup
public static synchronized Integer getNextID(Connection conn, String keyName, boolean inSession, boolean inGlobalTxn)
    throws Exception {
    
    try (PreparedStatement stmt = conn.prepareStatement(getKeyForUpdateSQL)) {
        stmt.setString(1, keyName);
        try (ResultSet rs = stmt.executeQuery()) {
            
            if (!rs.next()) {
                // Create new key with automatic resource management
                try (PreparedStatement createStmt = conn.prepareStatement(createKeySQL)) {
                    createStmt.setString(1, keyName);
                    createStmt.setInt(2, 0);
                    createStmt.executeUpdate();
                }
                // Resources automatically closed even if exception occurs
            }
            
            int keyVal = rs.getInt(1);
            
            // Update key value with proper resource management
            try (PreparedStatement updateStmt = conn.prepareStatement(updateKeyValueSQL)) {
                updateStmt.setInt(1, keyVal + TradeConfig.KEYBLOCKSIZE);
                updateStmt.setString(2, keyName);
                updateStmt.executeUpdate();
            }
            
            if (inGlobalTxn == false && !inSession) conn.commit();
            return keyVal;
        }
    } // All resources closed automatically
}
```

#### Why This Fix Works
- Try-with-resources guarantees resource cleanup
- Automatic cleanup even when exceptions occur
- Implements AutoCloseable interface pattern
- Eliminates manual cleanup error patterns

#### Implementation Steps
1. Identify manual resource management patterns in KeySequenceBean
2. Convert to try-with-resources blocks
3. Test exception handling scenarios
4. Monitor connection pool metrics post-deployment

---

### 🟠 N+1 Query Problem - High Priority

**Issue Description**: LAZY fetch relationships causing multiple queries during iteration
**Impact**: Database performance, response times, resource utilization
**Risk Level**: High
**Effort to Fix**: Medium

#### Current Code (Problematic)
```java
// ❌ Problematic: LAZY loading can cause N+1 queries (AccountDataBean.java)
@Entity(name = "accountejb")
public class AccountDataBean implements Serializable {
    
    @OneToMany(mappedBy = "account", fetch=FetchType.LAZY)
    private Collection<OrderDataBean> orders;
    
    @OneToMany(mappedBy = "account", fetch=FetchType.LAZY)  
    private Collection<HoldingDataBean> holdings;
    
    // Service method that triggers N+1 queries
    public void processAccountPortfolio(Integer accountID) {
        AccountDataBean account = entityManager.find(AccountDataBean.class, accountID);
        // This triggers additional queries for each holding/order!
        for (HoldingDataBean holding : account.getHoldings()) {
            calculateHoldingValue(holding); // Each access = new query
        }
    }
}
```

#### Recommended Fix
```java
// ✅ Fixed: Use fetch joins and entity graphs
@Entity(name = "accountejb")
@NamedQueries({
    @NamedQuery(name = "accountejb.findByAccountid_eager", 
                query = "SELECT a FROM accountejb a LEFT JOIN FETCH a.profile WHERE a.accountID = :accountid"),
    @NamedQuery(name = "accountejb.findWithHoldings", 
                query = "SELECT DISTINCT a FROM accountejb a LEFT JOIN FETCH a.holdings WHERE a.accountID = :accountid"),
    @NamedQuery(name = "accountejb.findWithOrdersAndHoldings",
                query = "SELECT DISTINCT a FROM accountejb a " +
                       "LEFT JOIN FETCH a.holdings h " +
                       "LEFT JOIN FETCH h.quote " +
                       "WHERE a.accountID = :accountid")
})
@EntityGraph(name = "Account.withPortfolio", 
             attributePaths = {"holdings", "holdings.quote", "orders", "profile"})
public class AccountDataBean implements Serializable {
    
    @OneToMany(mappedBy = "account", fetch=FetchType.LAZY)
    private Collection<OrderDataBean> orders;
    
    @OneToMany(mappedBy = "account", fetch=FetchType.LAZY)  
    private Collection<HoldingDataBean> holdings;
    
    // Enhanced repository with optimized queries
    @Repository
    public interface AccountRepository extends JpaRepository<AccountDataBean, Integer> {
        
        @EntityGraph("Account.withPortfolio")
        @Query("SELECT a FROM accountejb a WHERE a.accountID = :accountId")
        AccountDataBean findWithPortfolio(@Param("accountId") Integer accountId);
        
        @Query("SELECT DISTINCT a FROM accountejb a LEFT JOIN FETCH a.holdings WHERE a.accountID = :accountId")
        AccountDataBean findWithHoldings(@Param("accountId") Integer accountId);
    }
    
    // Service method with optimized data access
    @Service
    public class AccountService {
        
        public void processAccountPortfolio(Integer accountID) {
            // Single query fetches account with all holdings
            AccountDataBean account = accountRepository.findWithPortfolio(accountID);
            
            // No additional queries needed - all data pre-loaded
            for (HoldingDataBean holding : account.getHoldings()) {
                calculateHoldingValue(holding); // No additional database hits
            }
        }
    }
}
```

#### Why This Fix Works
- Single query with JOIN FETCH loads all related data
- Eliminates lazy loading during iteration
- @EntityGraph provides declarative fetch strategy
- Reduces database round trips from N+1 to 1

#### Implementation Steps
1. Identify N+1 query patterns in account/portfolio operations
2. Add @EntityGraph annotations to entities
3. Create optimized repository methods with JOIN FETCH
4. Test query performance with actual data volumes
5. Monitor query execution plans in production

---

### 🟡 Missing Caching Strategy - Medium Priority

**Issue Description**: Repeated expensive operations without caching
**Impact**: Performance, database load, response times
**Risk Level**: Medium
**Effort to Fix**: Medium

#### Current Code (Problematic)
```java
// ❌ Problematic: No caching for expensive operations (TradeSLSBBean.java)
@Stateless
public class TradeSLSBBean implements TradeSLSBLocal {
    
    @PersistenceContext
    private EntityManager entityManager;
    
    public QuoteDataBean getQuote(String symbol) {
        // Database hit every time - no caching
        return entityManager.find(QuoteDataBean.class, symbol);
    }
    
    public Collection<QuoteDataBean> getTopGainers() {
        // Complex query executed repeatedly
        Query query = entityManager.createNamedQuery("quoteejb.findTopGainers");
        return query.getResultList();
    }
    
    public MarketSummaryDataBean getMarketSummary() {
        // Expensive calculation performed repeatedly
        return calculateMarketSummary();
    }
}
```

#### Recommended Fix
```java
// ✅ Fixed: Implement JPA second-level cache with Spring Cache
@Entity(name = "quoteejb")
@Cacheable // Enable JPA second-level caching
@org.hibernate.annotations.Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
public class QuoteDataBean implements Serializable {
    // Entity definition remains the same
}

@Service
@CacheConfig(cacheNames = "trading")
public class TradingService {
    
    @PersistenceContext
    private EntityManager entityManager;
    
    @Cacheable(value = "quotes", key = "#symbol")
    public QuoteDataBean getQuote(String symbol) {
        // Result cached after first call
        return entityManager.find(QuoteDataBean.class, symbol);
    }
    
    @Cacheable(value = "topGainers", 
               key = "'topGainers'",
               unless = "#result == null || #result.isEmpty()")
    public Collection<QuoteDataBean> getTopGainers() {
        // Results cached for configured time period
        Query query = entityManager.createNamedQuery("quoteejb.findTopGainers");
        return query.getResultList();
    }
    
    @Cacheable(value = "marketSummary", 
               key = "'summary_' + T(java.time.LocalDate).now()",
               unless = "#result == null")
    public MarketSummaryDataBean getMarketSummary() {
        // Daily market summary cached
        return calculateMarketSummary();
    }
    
    @CacheEvict(value = {"quotes", "topGainers", "marketSummary"}, 
                key = "#quote.symbol")
    public QuoteDataBean updateQuote(QuoteDataBean quote) {
        // Cache cleared for updated quote
        return entityManager.merge(quote);
    }
}

// JPA Caching Configuration
@Configuration
public class JpaCacheConfiguration {
    
    @Bean
    public CacheManager cacheManager() {
        EhCacheCacheManager cacheManager = new EhCacheCacheManager();
        cacheManager.setCacheManager(ehCacheManagerFactory().getObject());
        return cacheManager;
    }
    
    @Bean
    public EhCacheManagerFactoryBean ehCacheManagerFactory() {
        EhCacheManagerFactoryBean factory = new EhCacheManagerFactoryBean();
        factory.setConfigLocation(new ClassPathResource("ehcache.xml"));
        return factory;
    }
}

// ehcache.xml configuration
<?xml version="1.0" encoding="UTF-8"?>
<ehcache xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:noNamespaceSchemaLocation="http://ehcache.org/ehcache.xsd">
    
    <cache name="quotes"
           maxElementsInMemory="1000"
           timeToLiveSeconds="300"
           timeToIdleSeconds="60"
           overflowToDisk="false"/>
    
    <cache name="topGainers"
           maxElementsInMemory="10"
           timeToLiveSeconds="60"
           timeToIdleSeconds="30"
           overflowToDisk="false"/>
    
    <cache name="marketSummary"
           maxElementsInMemory="1"
           timeToLiveSeconds="3600"
           timeToIdleSeconds="1800"
           overflowToDisk="false"/>
</ehcache>
```

#### Why This Fix Works
- @Cacheable prevents redundant database calls
- JPA second-level cache optimizes entity loading
- @CacheEvict maintains cache consistency
- Time-based expiration ensures data freshness

#### Implementation Steps
1. Enable JPA second-level caching in persistence.xml
2. Add @Cacheable annotations to frequently accessed entities
3. Implement application-level caching for service methods
4. Configure cache expiration policies based on data volatility
5. Monitor cache hit rates and tune accordingly

---

### 🔴 Mixed Data Access Patterns - Critical

**Issue Description**: Inconsistent use of JPA and direct JDBC creating performance unpredictability
**Impact**: Variable query performance, complex debugging, transaction boundary issues
**Risk Level**: Critical
**Effort to Fix**: High

#### Current Code (Problematic)
```java
// ❌ Problematic: Mixed JPA and JDBC patterns (TradeDirect.java)
public class TradeDirect implements TradeServices {
    
    private static DataSource datasource = null;
    
    @PersistenceContext
    private EntityManager entityManager;
    
    // JPA approach
    public AccountDataBean getAccountData(Integer accountID) {
        return entityManager.find(AccountDataBean.class, accountID);
    }
    
    // Direct JDBC approach in same class
    public HoldingDataBean createHolding(OrderDataBean order) throws Exception {
        Connection conn = null;
        try {
            conn = datasource.getConnection();
            // Direct SQL instead of JPA
            PreparedStatement stmt = conn.prepareStatement(createHoldingSQL);
            stmt.setInt(1, order.getOrderID());
            stmt.setString(2, order.getSymbol());
            // ... manual parameter setting
            stmt.executeUpdate();
            stmt.close();
        } finally {
            if (conn != null) conn.close();
        }
    }
}
```

#### Recommended Fix
```java
// ✅ Fixed: Standardized JPA approach with proper repositories
@Repository
@Transactional
public class AccountRepository {
    
    @PersistenceContext
    private EntityManager entityManager;
    
    public AccountDataBean findById(Integer accountID) {
        return entityManager.find(AccountDataBean.class, accountID);
    }
    
    public AccountDataBean findWithProfile(Integer accountID) {
        return entityManager.createNamedQuery("accountejb.findByAccountid_eager", AccountDataBean.class)
                          .setParameter("accountid", accountID)
                          .getSingleResult();
    }
    
    @Transactional
    public AccountDataBean updateBalance(Integer accountID, BigDecimal amount) {
        AccountDataBean account = findById(accountID);
        if (account != null) {
            account.setBalance(account.getBalance().add(amount));
            return entityManager.merge(account);
        }
        return null;
    }
}

@Repository
@Transactional
public class HoldingRepository {
    
    @PersistenceContext
    private EntityManager entityManager;
    
    @Transactional
    public HoldingDataBean createHolding(OrderDataBean order) {
        HoldingDataBean holding = new HoldingDataBean();
        holding.setAccount(order.getAccount());
        holding.setQuote(order.getQuote());
        holding.setQuantity(order.getQuantity());
        holding.setPurchasePrice(order.getPrice());
        holding.setPurchaseDate(new Timestamp(System.currentTimeMillis()));
        
        entityManager.persist(holding);
        return holding;
    }
    
    public Collection<HoldingDataBean> findByAccount(Integer accountID) {
        return entityManager.createNamedQuery("holdingejb.findByAccount", HoldingDataBean.class)
                          .setParameter("accountID", accountID)
                          .getResultList();
    }
}

@Service
@Transactional
public class TradingService implements TradeServices {
    
    @Autowired
    private AccountRepository accountRepository;
    
    @Autowired
    private HoldingRepository holdingRepository;
    
    @Autowired
    private OrderRepository orderRepository;
    
    @Override
    @Transactional
    public OrderDataBean buy(String userID, String symbol, double quantity) throws Exception {
        
        // Consistent JPA approach throughout
        AccountDataBean account = accountRepository.findByUserID(userID);
        QuoteDataBean quote = quoteRepository.findBySymbol(symbol);
        
        // Business logic using JPA entities
        BigDecimal total = calculateOrderTotal(quote.getPrice(), quantity, true);
        
        if (account.getBalance().compareTo(total) < 0) {
            throw new Exception("Insufficient funds");
        }
        
        // Create order using JPA
        OrderDataBean order = new OrderDataBean();
        order.setOrderType("buy");
        order.setAccount(account);
        order.setQuote(quote);
        order.setQuantity(quantity);
        order.setPrice(quote.getPrice());
        order.setOrderFee(TradeConfig.getOrderFee());
        order.setCompletionDate(new Timestamp(System.currentTimeMillis()));
        
        order = orderRepository.save(order);
        
        // Update account balance
        account.setBalance(account.getBalance().subtract(total));
        accountRepository.save(account);
        
        // Create holding
        HoldingDataBean holding = holdingRepository.createHolding(order);
        
        return order;
    }
}
```

#### Why This Fix Works
- Consistent JPA usage eliminates performance unpredictability
- Spring Data repositories provide optimized query handling
- @Transactional ensures proper transaction boundaries
- EntityManager provides automatic connection management

#### Implementation Steps
1. Audit all data access patterns in the application
2. Create JPA repositories for all entity types
3. Migrate JDBC operations to JPA equivalents
4. Update service layer to use repositories consistently
5. Remove direct JDBC/DataSource dependencies
6. Test transaction behavior thoroughly

---

## Implementation Priority Matrix

| Issue | Severity | Effort | Business Impact | Priority |
|-------|----------|--------|-----------------|----------|
| Resource Management | 🔴 Critical | Low | High | 1 |
| Mixed Data Access | 🔴 Critical | High | High | 2 |
| N+1 Queries | 🟠 High | Medium | Medium | 3 |
| Missing Caching | 🟡 Medium | Medium | Medium | 4 |

## Testing Strategy

### Performance Testing
1. **Load Testing**: Simulate high-volume trading scenarios
2. **Memory Testing**: Monitor heap usage and garbage collection
3. **Connection Pool Testing**: Verify proper resource cleanup
4. **Query Performance**: Measure database query response times

### Validation Criteria
- **Resource Leaks**: Zero connection leaks under sustained load
- **Query Performance**: 40-60% reduction in database round trips
- **Response Times**: P95 latency under 100ms for trading operations
- **Cache Hit Rates**: 80%+ hit rate for quote and market data

---

*Performance fixes based on DayTrader3 codebase analysis - 2025-09-12*