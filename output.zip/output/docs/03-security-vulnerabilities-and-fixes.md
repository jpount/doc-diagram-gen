# Security Vulnerabilities and Fixes: DayTrader3

## Overview
This document provides specific fixes and secure code examples for security vulnerabilities identified in the DayTrader3 financial trading application analysis.

🚨 **CRITICAL**: All security fixes should be implemented immediately and thoroughly tested before production deployment.

## OWASP Top 10 Mapping
The vulnerabilities identified map to the following OWASP Top 10 categories:
- A02:2021 – Cryptographic Failures
- A07:2021 – Identification and Authentication Failures
- A03:2021 – Injection
- A01:2021 – Broken Access Control
- A05:2021 – Security Misconfiguration

## Vulnerabilities and Solutions

### 🚨 Plaintext Password Storage and Comparison - Critical

**Vulnerability Description**: Passwords stored and compared in plaintext without hashing
**Impact**: Complete account compromise, credential theft, regulatory violations
**Risk Level**: Critical
**Effort to Fix**: Medium
**OWASP Category**: A07:2021 – Identification and Authentication Failures

#### Vulnerable Code
```java
// ❌ CRITICAL VULNERABILITY: Plaintext password comparison
public AccountDataBean login(String userID, String password) throws Exception {
    conn = getConn();
    PreparedStatement stmt = getStatement(conn, getAccountProfileSQL);
    stmt.setString(1, userID);
    
    ResultSet rs = stmt.executeQuery();
    if (!rs.next()) {
        throw new FinderException("Cannot find account for" + userID);
    }
    
    String pw = rs.getString("passwd");
    stmt.close();
    if ((pw == null) || (pw.equals(password) == false)) {  // CRITICAL: Plaintext comparison!
        String error = "Login failure for user: " + userID + 
                      "\n\tIncorrect password-->" + userID + ":" + password;  // CRITICAL: Password in logs!
        Log.error(error);
        throw new Exception(error);
    }
    // ... rest of login logic
}

// ❌ CRITICAL: Password stored in plaintext database
private static final String createAccountProfileSQL = 
    "insert into accountprofileejb (userid, passwd, fullname, address, email, creditcard) " +
    "VALUES (?, ?, ?, ?, ?, ?)";  // Plaintext password storage!
```

#### Secure Implementation
```java
// ✅ SECURE: BCrypt password hashing implementation
@Service
public class SecurityService {
    
    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder(12);
    private final SecurityAuditLogger auditLogger;
    
    public String hashPassword(String plainPassword) {
        return passwordEncoder.encode(plainPassword);
    }
    
    public boolean verifyPassword(String plainPassword, String hashedPassword) {
        return passwordEncoder.matches(plainPassword, hashedPassword);
    }
}

@Repository
public class SecureUserRepository {
    
    @Autowired
    private SecurityService securityService;
    
    @Autowired
    private SecurityAuditLogger auditLogger;
    
    public AccountDataBean login(String userID, String password, HttpServletRequest request) {
        try {
            PreparedStatement stmt = getStatement(conn, getAccountProfileSQL);
            stmt.setString(1, userID);
            
            ResultSet rs = stmt.executeQuery();
            if (!rs.next()) {
                auditLogger.logFailedLogin(userID, request.getRemoteAddr(), "USER_NOT_FOUND");
                throw new FinderException("Invalid credentials");  // Generic error message
            }
            
            String hashedPassword = rs.getString("passwd");
            stmt.close();
            
            if (!securityService.verifyPassword(password, hashedPassword)) {
                auditLogger.logFailedLogin(userID, request.getRemoteAddr(), "INVALID_PASSWORD");
                // Implement account lockout after failed attempts
                incrementFailedAttempts(userID);
                throw new Exception("Invalid credentials");  // Generic error message
            }
            
            // Reset failed attempts on successful login
            resetFailedAttempts(userID);
            auditLogger.logSuccessfulLogin(userID, request.getRemoteAddr());
            
            // Continue with login logic
            return getAccountData(conn, userID);
            
        } catch (Exception e) {
            // ✅ SECURE: No sensitive data in logs
            Log.error("Login attempt failed for user: " + userID);
            throw new Exception("Invalid credentials");
        }
    }
    
    public void register(String userID, String plainPassword, String fullname, 
                        String address, String email, String creditcard, 
                        BigDecimal openBalance) throws Exception {
        
        // ✅ SECURE: Password policy validation
        if (!isPasswordStrong(plainPassword)) {
            throw new WeakPasswordException(
                "Password must be at least 12 characters with uppercase, lowercase, numbers, and symbols"
            );
        }
        
        // ✅ SECURE: Hash password before storage
        String hashedPassword = securityService.hashPassword(plainPassword);
        
        PreparedStatement stmt = getStatement(conn, createAccountProfileSQL);
        stmt.setString(1, userID);
        stmt.setString(2, hashedPassword);  // Store hashed password
        stmt.setString(3, fullname);
        stmt.setString(4, address);
        stmt.setString(5, email);
        stmt.setString(6, encryptCreditCard(creditcard));  // Encrypt sensitive data
        stmt.executeUpdate();
        
        auditLogger.logUserRegistration(userID);
    }
    
    private boolean isPasswordStrong(String password) {
        return password.length() >= 12 &&
               password.matches(".*[A-Z].*") &&  // uppercase
               password.matches(".*[a-z].*") &&  // lowercase  
               password.matches(".*[0-9].*") &&  // digits
               password.matches(".*[!@#$%^&*()].*");  // symbols
    }
}

// ✅ SECURE: Account lockout mechanism
@Component
public class AccountLockoutService {
    
    private final Map<String, AttemptInfo> failedAttempts = new ConcurrentHashMap<>();
    
    public void incrementFailedAttempts(String userID) {
        AttemptInfo info = failedAttempts.computeIfAbsent(userID, k -> new AttemptInfo());
        info.incrementAttempts();
        
        if (info.getAttempts() >= 5) {
            info.lockAccount(Duration.ofMinutes(30));  // Lock for 30 minutes
            auditLogger.logAccountLocked(userID, "FAILED_LOGIN_ATTEMPTS");
        }
    }
    
    public boolean isAccountLocked(String userID) {
        AttemptInfo info = failedAttempts.get(userID);
        return info != null && info.isLocked();
    }
}
```

#### Why This Fix Works
- BCrypt provides secure password hashing with automatic salt generation
- Variable cost factor (12) makes brute force attacks computationally expensive
- Constant-time comparison prevents timing attacks
- Account lockout mechanism prevents brute force attacks
- Generic error messages prevent user enumeration attacks

#### Implementation Steps
1. Add Spring Security dependencies to pom.xml
2. Implement SecurityService with BCrypt password encoder
3. Update database schema to increase password field size for hashes
4. Migrate existing plaintext passwords to hashed versions
5. Update all authentication logic to use secure password verification
6. Implement account lockout mechanism
7. Add comprehensive security audit logging

---

### 🔴 Unencrypted Sensitive Data Storage - Critical

**Vulnerability Description**: Credit card numbers, personal information, and financial data stored in plaintext
**Impact**: PCI DSS violations, massive fines, identity theft, financial fraud
**Risk Level**: Critical
**Effort to Fix**: High
**OWASP Category**: A02:2021 – Cryptographic Failures

#### Vulnerable Code
```java
// ❌ CRITICAL VULNERABILITY: Plaintext sensitive data storage
@Entity
@Table(name = "ACCOUNTPROFILEEJB")
public class AccountProfileDataBean {
    
    @Column(name = "CREDITCARD")
    private String creditCard;  // CRITICAL: Plaintext credit card storage!
    
    @Column(name = "EMAIL")
    private String email;  // PII stored without encryption
    
    @Column(name = "FULLNAME")
    private String fullName;  // PII stored without encryption
    
    @Column(name = "ADDRESS") 
    private String address;  // PII stored without encryption
    
    // Database table definition - CRITICAL PCI DSS violation
    // CREATE TABLE ACCOUNTPROFILEEJB (CREDITCARD VARCHAR(250))
}

// ❌ CRITICAL: Credit card displayed in HTML
public String toHTML() {
    return "<LI> creditCard:" + getCreditCard() + "</LI>";  // CRITICAL: CC exposed in HTML!
}
```

#### Secure Implementation
```java
// ✅ SECURE: Field-level encryption for sensitive data
@Entity
@Table(name = "ACCOUNTPROFILEEJB")
public class SecureAccountProfileDataBean {
    
    @Convert(converter = CreditCardEncryptor.class)
    @Column(name = "CREDITCARD")
    private String creditCard;  // Encrypted storage
    
    @Convert(converter = PIIEncryptor.class)
    @Column(name = "EMAIL")
    private String email;  // Encrypted PII
    
    @Convert(converter = PIIEncryptor.class)
    @Column(name = "FULLNAME") 
    private String fullName;  // Encrypted PII
    
    @Convert(converter = PIIEncryptor.class)
    @Column(name = "ADDRESS")
    private String address;  // Encrypted PII
    
    // ✅ SECURE: Masked display for sensitive data
    public String toHTML() {
        return "<LI>creditCard:" + maskCreditCard(getCreditCard()) + "</LI>";
    }
    
    private String maskCreditCard(String creditCard) {
        if (creditCard == null || creditCard.length() < 8) return "****";
        return "****-****-****-" + creditCard.substring(creditCard.length() - 4);
    }
}

// ✅ SECURE: AES-256 encryption for credit card data
@Component
public class CreditCardEncryptor implements AttributeConverter<String, String> {
    
    private final AESUtil encryptionUtil;
    
    @Override
    public String convertToDatabaseColumn(String creditCard) {
        if (creditCard == null) return null;
        try {
            // ✅ PCI DSS compliant AES-256 encryption
            return encryptionUtil.encrypt(creditCard);
        } catch (Exception e) {
            throw new EncryptionException("Failed to encrypt credit card data", e);
        }
    }
    
    @Override
    public String convertToEntityAttribute(String encryptedData) {
        if (encryptedData == null) return null;
        try {
            return encryptionUtil.decrypt(encryptedData);
        } catch (Exception e) {
            throw new DecryptionException("Failed to decrypt credit card data", e);
        }
    }
}

// ✅ SECURE: AES-256-GCM encryption utility
@Component
public class AESUtil {
    
    private final KeyService keyService;
    private static final String ALGORITHM = "AES";
    private static final String TRANSFORMATION = "AES/GCM/NoPadding";
    
    public String encrypt(String plaintext) throws Exception {
        SecretKey key = keyService.getDataEncryptionKey();
        Cipher cipher = Cipher.getInstance(TRANSFORMATION);
        cipher.init(Cipher.ENCRYPT_MODE, key);
        
        byte[] iv = cipher.getIV();
        byte[] encryptedData = cipher.doFinal(plaintext.getBytes(StandardCharsets.UTF_8));
        
        // Combine IV + encrypted data
        byte[] encryptedWithIv = new byte[iv.length + encryptedData.length];
        System.arraycopy(iv, 0, encryptedWithIv, 0, iv.length);
        System.arraycopy(encryptedData, 0, encryptedWithIv, iv.length, encryptedData.length);
        
        return Base64.getEncoder().encodeToString(encryptedWithIv);
    }
    
    public String decrypt(String encryptedData) throws Exception {
        byte[] decodedData = Base64.getDecoder().decode(encryptedData);
        
        // Extract IV and encrypted data
        byte[] iv = new byte[12];  // GCM IV size
        byte[] encrypted = new byte[decodedData.length - 12];
        System.arraycopy(decodedData, 0, iv, 0, 12);
        System.arraycopy(decodedData, 12, encrypted, 0, encrypted.length);
        
        SecretKey key = keyService.getDataEncryptionKey();
        Cipher cipher = Cipher.getInstance(TRANSFORMATION);
        GCMParameterSpec gcmSpec = new GCMParameterSpec(128, iv);
        cipher.init(Cipher.DECRYPT_MODE, key, gcmSpec);
        
        byte[] decryptedData = cipher.doFinal(encrypted);
        return new String(decryptedData, StandardCharsets.UTF_8);
    }
}

// ✅ SECURE: Key management service
@Service
public class KeyService {
    
    @Value("${app.encryption.key.alias}")
    private String keyAlias;
    
    private final KeyStore keyStore;
    
    public SecretKey getDataEncryptionKey() throws Exception {
        // ✅ SECURE: Load key from secure key store (HSM, AWS KMS, etc.)
        return (SecretKey) keyStore.getKey(keyAlias, getKeyPassword());
    }
    
    private char[] getKeyPassword() {
        // ✅ SECURE: Load from secure environment variable or vault
        String password = System.getenv("DATA_ENCRYPTION_KEY_PASSWORD");
        return password.toCharArray();
    }
    
    @PostConstruct
    public void rotateKeyIfNeeded() {
        // ✅ SECURE: Implement automatic key rotation
        LocalDateTime lastRotation = getLastKeyRotation();
        if (ChronoUnit.DAYS.between(lastRotation, LocalDateTime.now()) > 90) {
            scheduleKeyRotation();
        }
    }
}

// ✅ SECURE: Database table with proper encryption field sizes
/*
CREATE TABLE ACCOUNTPROFILEEJB (
    USERID VARCHAR(250) NOT NULL,
    PASSWD VARCHAR(255) NOT NULL,  -- Increased for bcrypt hashes
    FULLNAME TEXT,                 -- Encrypted data needs more space
    ADDRESS TEXT,                  -- Encrypted data needs more space
    EMAIL TEXT,                    -- Encrypted data needs more space  
    CREDITCARD TEXT,               -- Encrypted data needs more space
    ENCRYPTION_VERSION INT,        -- Track encryption version for key rotation
    CREATED_DATE TIMESTAMP,
    UPDATED_DATE TIMESTAMP
);
*/
```

#### Why This Fix Works
- AES-256-GCM provides authenticated encryption preventing tampering
- Field-level encryption protects data at rest in database
- Separate encryption keys for different data types
- Key rotation mechanism prevents key compromise issues
- Masked display prevents accidental data exposure
- Compliant with PCI DSS requirements for cardholder data protection

#### Implementation Steps
1. Set up secure key management system (HSM, AWS KMS, or secure key store)
2. Implement AES-256-GCM encryption utility classes
3. Create JPA attribute converters for automatic encryption/decryption
4. Update database schema to accommodate encrypted data
5. Implement data migration strategy for existing plaintext data
6. Add key rotation mechanisms
7. Update all data access patterns to handle encrypted fields
8. Implement secure key backup and recovery procedures

---

### 🟠 Cross-Site Scripting (XSS) Vulnerabilities - High

**Vulnerability Description**: User input rendered directly in JSP pages without proper escaping
**Impact**: Session hijacking, credential theft, malicious script execution
**Risk Level**: High  
**Effort to Fix**: Medium
**OWASP Category**: A03:2021 – Injection

#### Vulnerable Code
```jsp
<!-- ❌ XSS VULNERABILITY: Direct parameter output without escaping -->
<%
String creditcard = request.getParameter("Credit Card Number");  // User input
String fullname = request.getParameter("Full Name");           // User input  
String email = request.getParameter("email");                  // User input
%>

<INPUT size="40" type="text" name="Credit Card Number" 
       value="<%= creditcard==null ? fakeCC : creditcard %>">  <!-- CRITICAL: XSS! -->

<INPUT size="30" type="text" name="Full Name"
       value="<%= fullname==null ? "" : fullname %>">         <!-- CRITICAL: XSS! -->
       
<INPUT size="30" type="text" name="email" 
       value="<%= email==null ? "" : email %>">               <!-- CRITICAL: XSS! -->

<!-- ❌ CRITICAL: Account data exposed without escaping -->  
<TD><%= accountProfileData.getFullName() %></TD>              <!-- XSS vulnerability -->
<TD><%= accountProfileData.getEmail() %></TD>                 <!-- XSS vulnerability -->
```

#### Secure Implementation
```jsp
<!-- ✅ SECURE: Proper input validation and output encoding -->
<%@ page import="org.apache.commons.text.StringEscapeUtils" %>
<%@ page import="com.ibm.websphere.samples.daytrader.security.InputValidator" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/functions" prefix="fn" %>

<%
// ✅ SECURE: Input validation and sanitization
String creditcard = InputValidator.validateCreditCard(request.getParameter("Credit Card Number"));
String fullname = InputValidator.validateName(request.getParameter("Full Name"));
String email = InputValidator.validateEmail(request.getParameter("email"));

// ✅ SECURE: HTML escaping for output
String safeCreditcard = StringEscapeUtils.escapeHtml4(creditcard);
String safeFullname = StringEscapeUtils.escapeHtml4(fullname);  
String safeEmail = StringEscapeUtils.escapeHtml4(email);
%>

<!-- ✅ SECURE: Escaped output and JSTL functions -->
<INPUT size="40" type="text" name="Credit Card Number" 
       value="<c:out value='${safeCreditcard}' default='${fakeCC}' escapeXml='true'/>">

<INPUT size="30" type="text" name="Full Name"
       value="<c:out value='${safeFullname}' default='' escapeXml='true'/>">
       
<INPUT size="30" type="text" name="email" 
       value="<c:out value='${safeEmail}' default='' escapeXml='true'/>">

<!-- ✅ SECURE: Escaped account data display -->
<TD><c:out value="${fn:escapeXml(accountProfileData.fullName)}" /></TD>
<TD><c:out value="${fn:escapeXml(accountProfileData.email)}" /></TD>
```

```java
// ✅ SECURE: Input validation utility class
@Component  
public class InputValidator {
    
    private static final Pattern EMAIL_PATTERN = 
        Pattern.compile("^[A-Za-z0-9+_.-]+@([A-Za-z0-9.-]+\\.[A-Za-z]{2,})$");
    
    private static final Pattern NAME_PATTERN = 
        Pattern.compile("^[a-zA-Z\\s'-]{1,100}$");
        
    private static final Pattern CREDITCARD_PATTERN = 
        Pattern.compile("^[0-9]{4}-[0-9]{4}-[0-9]{4}-[0-9]{4}$");
    
    public static String validateEmail(String email) {
        if (email == null || email.trim().isEmpty()) {
            return "";
        }
        
        String trimmed = email.trim();
        if (trimmed.length() > 254) {  // RFC 5321 limit
            throw new InvalidInputException("Email too long");
        }
        
        if (!EMAIL_PATTERN.matcher(trimmed).matches()) {
            throw new InvalidInputException("Invalid email format");
        }
        
        return sanitizeInput(trimmed);
    }
    
    public static String validateName(String name) {
        if (name == null || name.trim().isEmpty()) {
            return "";
        }
        
        String trimmed = name.trim();
        if (trimmed.length() > 100) {
            throw new InvalidInputException("Name too long");
        }
        
        if (!NAME_PATTERN.matcher(trimmed).matches()) {
            throw new InvalidInputException("Invalid name format");
        }
        
        return sanitizeInput(trimmed);
    }
    
    public static String validateCreditCard(String creditCard) {
        if (creditCard == null || creditCard.trim().isEmpty()) {
            return "";
        }
        
        String trimmed = creditCard.trim();
        if (!CREDITCARD_PATTERN.matcher(trimmed).matches()) {
            throw new InvalidInputException("Invalid credit card format");
        }
        
        // Additional Luhn algorithm validation
        if (!isValidLuhn(trimmed.replaceAll("-", ""))) {
            throw new InvalidInputException("Invalid credit card number");
        }
        
        return sanitizeInput(trimmed);
    }
    
    private static String sanitizeInput(String input) {
        // Remove potentially dangerous characters
        return input.replaceAll("[<>\"'&]", "");
    }
    
    private static boolean isValidLuhn(String cardNumber) {
        // Implement Luhn algorithm for credit card validation
        int sum = 0;
        boolean alternate = false;
        
        for (int i = cardNumber.length() - 1; i >= 0; i--) {
            int n = Integer.parseInt(cardNumber.substring(i, i + 1));
            if (alternate) {
                n *= 2;
                if (n > 9) {
                    n = (n % 10) + 1;
                }
            }
            sum += n;
            alternate = !alternate;
        }
        
        return (sum % 10 == 0);
    }
}

// ✅ SECURE: Content Security Policy servlet filter
@WebFilter("/*")
public class SecurityHeaderFilter implements Filter {
    
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, 
                        FilterChain chain) throws IOException, ServletException {
        
        HttpServletResponse httpResponse = (HttpServletResponse) response;
        
        // ✅ SECURE: Content Security Policy to prevent XSS
        httpResponse.setHeader("Content-Security-Policy", 
            "default-src 'self'; " +
            "script-src 'self' 'unsafe-inline'; " +  // Minimize unsafe-inline usage
            "style-src 'self' 'unsafe-inline'; " +
            "img-src 'self' data: https:; " +
            "font-src 'self'; " +
            "connect-src 'self'; " +
            "frame-ancestors 'none'");
            
        // ✅ SECURE: Additional security headers
        httpResponse.setHeader("X-Content-Type-Options", "nosniff");
        httpResponse.setHeader("X-Frame-Options", "DENY");
        httpResponse.setHeader("X-XSS-Protection", "1; mode=block");
        httpResponse.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
        
        chain.doFilter(request, response);
    }
}
```

#### Why This Fix Works
- Input validation prevents malicious data from entering the system
- Output encoding ensures dangerous characters are safely displayed
- JSTL functions provide built-in XSS protection
- Content Security Policy provides defense-in-depth against XSS attacks
- Security headers add additional browser-level protections

#### Implementation Steps
1. Add Apache Commons Text dependency for StringEscapeUtils
2. Implement comprehensive InputValidator utility class
3. Update all JSP pages to use JSTL and proper output encoding
4. Add SecurityHeaderFilter for Content Security Policy
5. Replace all direct parameter output with validated and escaped versions
6. Implement input validation on all form submissions
7. Add automated XSS testing to security test suite

---

### 🟠 Missing Authentication and Authorization Controls - High

**Vulnerability Description**: No role-based access control or method-level authorization
**Impact**: Unauthorized access to financial operations, privilege escalation
**Risk Level**: High
**Effort to Fix**: High  
**OWASP Category**: A01:2021 – Broken Access Control

#### Vulnerable Code
```java
// ❌ CRITICAL VULNERABILITY: No authorization checks
@Stateless
public class TradeSLSBBean implements TradeSLSBLocal {
    
    // ❌ CRITICAL: Any authenticated user can perform any operation
    public OrderDataBean buy(String userID, String symbol, double quantity) throws Exception {
        // No check if current user matches userID
        // No check if user has trading privileges  
        // No check for account status or limits
        return tradeDirect.buy(userID, symbol, quantity);
    }
    
    public OrderDataBean sell(String userID, Integer holdingID) throws Exception {
        // ❌ CRITICAL: No ownership verification of holding
        // Any user can sell any other user's holdings
        return tradeDirect.sell(userID, holdingID);
    }
    
    public AccountDataBean getAccountData(String userID) throws Exception {
        // ❌ CRITICAL: Any user can access any account data
        return tradeDirect.getAccountData(userID);
    }
    
    public Collection<OrderDataBean> getOrders(String userID) throws Exception {
        // ❌ CRITICAL: No authorization check for viewing orders
        return tradeDirect.getOrders(userID);
    }
}

// ❌ No security configuration in web.xml
// Missing: <security-constraint>, <auth-constraint>, <login-config>
```

#### Secure Implementation
```java
// ✅ SECURE: Role-based access control with Spring Security
@Stateless
@PreAuthorize("hasRole('TRADER')")  // Require TRADER role for all methods
public class SecureTradeSLSBBean implements TradeSLSBLocal {
    
    @Autowired
    private SecurityContext securityContext;
    
    @Autowired
    private AuthorizationService authorizationService;
    
    @PreAuthorize("hasRole('TRADER') and #userID == authentication.name")
    public OrderDataBean buy(String userID, String symbol, double quantity) throws Exception {
        
        // ✅ SECURE: Additional business authorization checks
        if (!authorizationService.canUserTrade(userID)) {
            throw new AccessDeniedException("User trading privileges suspended");
        }
        
        // ✅ SECURE: Account status and limit checks
        AccountDataBean account = getAccountData(userID);
        if (!isAccountActive(account)) {
            throw new AccountInactiveException("Account is not active for trading");
        }
        
        // ✅ SECURE: Trading limit validation
        BigDecimal orderValue = BigDecimal.valueOf(quantity).multiply(getQuotePrice(symbol));
        if (!authorizationService.isWithinTradingLimits(userID, orderValue)) {
            throw new TradingLimitExceededException("Order exceeds trading limits");
        }
        
        return tradeDirect.buy(userID, symbol, quantity);
    }
    
    @PreAuthorize("hasRole('TRADER') and #userID == authentication.name")
    public OrderDataBean sell(String userID, Integer holdingID) throws Exception {
        
        // ✅ SECURE: Ownership verification
        HoldingDataBean holding = getHolding(holdingID);
        if (!holding.getAccount().getProfile().getUserID().equals(userID)) {
            throw new AccessDeniedException("User does not own this holding");
        }
        
        // ✅ SECURE: Account status check
        if (!authorizationService.canUserTrade(userID)) {
            throw new AccessDeniedException("User trading privileges suspended");
        }
        
        return tradeDirect.sell(userID, holdingID);
    }
    
    @PreAuthorize("hasRole('USER') and (#userID == authentication.name or hasRole('ADMIN'))")
    public AccountDataBean getAccountData(String userID) throws Exception {
        
        String currentUser = securityContext.getAuthentication().getName();
        
        // ✅ SECURE: Users can only access their own data (unless admin)
        if (!currentUser.equals(userID) && !hasRole("ADMIN")) {
            auditLogger.logUnauthorizedAccess(currentUser, "ACCOUNT_DATA", userID);
            throw new AccessDeniedException("Cannot access other user's account data");
        }
        
        return tradeDirect.getAccountData(userID);
    }
    
    @PreAuthorize("hasRole('TRADER') and #userID == authentication.name")
    public Collection<OrderDataBean> getOrders(String userID) throws Exception {
        
        // ✅ SECURE: Additional authorization logging
        auditLogger.logOrderAccess(securityContext.getAuthentication().getName(), userID);
        
        return tradeDirect.getOrders(userID);
    }
    
    // ✅ SECURE: Admin-only operations  
    @PreAuthorize("hasRole('ADMIN')")
    public void suspendUserTrading(String userID, String reason) {
        authorizationService.suspendTrading(userID, reason);
        auditLogger.logTradingSuspension(
            securityContext.getAuthentication().getName(), userID, reason);
    }
    
    @PreAuthorize("hasRole('ADMIN')")
    public RunStatsDataBean resetTrade(boolean deleteAll) throws Exception {
        auditLogger.logSystemReset(securityContext.getAuthentication().getName(), deleteAll);
        return tradeDirect.resetTrade(deleteAll);
    }
}

// ✅ SECURE: Authorization service for business rules
@Service
public class AuthorizationService {
    
    @Autowired
    private UserStatusRepository userStatusRepository;
    
    public boolean canUserTrade(String userID) {
        UserStatus status = userStatusRepository.findByUserID(userID);
        return status != null && 
               status.isActive() && 
               !status.isTradingSuspended() &&
               status.isEmailVerified();
    }
    
    public boolean isWithinTradingLimits(String userID, BigDecimal orderValue) {
        UserStatus status = userStatusRepository.findByUserID(userID);
        if (status == null) return false;
        
        // Check daily trading limit
        BigDecimal dailyLimit = status.getDailyTradingLimit();
        BigDecimal todayVolume = getTodayTradingVolume(userID);
        
        return todayVolume.add(orderValue).compareTo(dailyLimit) <= 0;
    }
    
    public void suspendTrading(String userID, String reason) {
        UserStatus status = userStatusRepository.findByUserID(userID);
        if (status != null) {
            status.setTradingSuspended(true);
            status.setSuspensionReason(reason);
            status.setSuspensionDate(LocalDateTime.now());
            userStatusRepository.save(status);
        }
    }
    
    private BigDecimal getTodayTradingVolume(String userID) {
        LocalDate today = LocalDate.now();
        return orderRepository.getTotalVolumeForUserOnDate(userID, today);
    }
}

// ✅ SECURE: Security configuration  
@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class WebSecurityConfig {
    
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/login", "/register", "/docs/**").permitAll()
                .requestMatchers("/admin/**").hasRole("ADMIN")
                .requestMatchers("/api/trade/**").hasRole("TRADER")  
                .requestMatchers("/api/account/**").hasRole("USER")
                .anyRequest().authenticated()
            )
            .formLogin(form -> form
                .loginPage("/login")
                .defaultSuccessUrl("/dashboard")
                .failureUrl("/login?error")
                .permitAll()
            )
            .logout(logout -> logout
                .logoutUrl("/logout")
                .logoutSuccessUrl("/login?logout")
                .invalidateHttpSession(true)
                .deleteCookies("JSESSIONID")
            )
            .sessionManagement(session -> session
                .sessionCreationPolicy(SessionCreationPolicy.IF_REQUIRED)
                .maximumSessions(1)
                .maxSessionsPreventsLogin(true)
            )
            .csrf(csrf -> csrf
                .csrfTokenRepository(CookieCsrfTokenRepository.withHttpOnlyFalse())
            );
            
        return http.build();
    }
}

<!-- ✅ SECURE: web.xml security constraints -->
<web-app>
    <security-constraint>
        <web-resource-collection>
            <web-resource-name>Trading Operations</web-resource-name>
            <url-pattern>/api/trade/*</url-pattern>
            <http-method>GET</http-method>
            <http-method>POST</http-method>
        </web-resource-collection>
        <auth-constraint>
            <role-name>TRADER</role-name>
        </auth-constraint>
        <user-data-constraint>
            <transport-guarantee>CONFIDENTIAL</transport-guarantee>  <!-- HTTPS only -->
        </user-data-constraint>
    </security-constraint>
    
    <security-constraint>
        <web-resource-collection>
            <web-resource-name>Account Management</web-resource-name>
            <url-pattern>/api/account/*</url-pattern>
        </web-resource-collection>
        <auth-constraint>
            <role-name>USER</role-name>
        </auth-constraint>
        <user-data-constraint>
            <transport-guarantee>CONFIDENTIAL</transport-guarantee>
        </user-data-constraint>
    </security-constraint>
    
    <login-config>
        <auth-method>FORM</auth-method>
        <form-login-config>
            <form-login-page>/login</form-login-page>
            <form-error-page>/login?error</form-error-page>
        </form-login-config>
    </login-config>
    
    <security-role>
        <role-name>USER</role-name>
    </security-role>
    <security-role>
        <role-name>TRADER</role-name>
    </security-role>  
    <security-role>
        <role-name>ADMIN</role-name>
    </security-role>
</web-app>
```

#### Why This Fix Works
- Method-level security ensures authorization checks on every operation
- Role-based access control provides fine-grained permission management
- Ownership verification prevents unauthorized access to other users' data
- Business authorization rules enforce trading limits and account status
- Security constraints in web.xml provide URL-level access control
- HTTPS enforcement protects data in transit

#### Implementation Steps
1. Add Spring Security dependencies and configuration
2. Implement role-based security with proper user roles (USER, TRADER, ADMIN)
3. Add @PreAuthorize annotations to all business methods
4. Implement AuthorizationService for business rule validation
5. Add ownership verification for all data access operations
6. Configure security constraints in web.xml
7. Implement comprehensive authorization audit logging
8. Add automated authorization testing

---

## Summary

The DayTrader3 application requires comprehensive security remediation across multiple layers:

### Critical Fixes (Immediate Implementation Required)
1. **🚨 Password Security**: Implement BCrypt hashing and secure password policies
2. **🚨 Data Encryption**: Encrypt sensitive data at rest with AES-256
3. **🔴 Input Validation**: Add comprehensive XSS and injection protection
4. **🔴 Access Control**: Implement role-based authorization throughout the application

### Implementation Priority
- **Week 1-2**: Password security and authentication fixes  
- **Week 3-4**: Data encryption and PCI DSS compliance
- **Week 5-6**: Input validation and XSS protection
- **Week 7-8**: Access control and authorization framework

### Success Metrics
- ✅ Zero critical security vulnerabilities
- ✅ PCI DSS compliance certification  
- ✅ All security unit tests passing
- ✅ Successful penetration testing results

**Total Estimated Effort**: 8-12 weeks with dedicated security team

All fixes should be thoroughly tested in development and staging environments before production deployment. Regular security assessments and code reviews should be implemented to maintain security posture.

---

*This security remediation guide provides specific, actionable fixes for identified vulnerabilities. Each fix includes secure code examples and implementation guidance for the development team.*