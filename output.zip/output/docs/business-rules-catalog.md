# Business Rules Catalog

**Generated**: 2025-09-12T12:00:00.000Z  
**Purpose**: Detailed documentation of ALL business logic for understanding and potential rewrites  
**Total Rules**: 25 comprehensive business rules  
**Project**: daytrader (Java-based Trading Application)

## Overview

This catalog provides **implementation-level detail** for every business rule identified in the daytrader application. Each rule includes exact code location, business logic description, implementation details, and modernization preservation requirements.

## Rule Categories

### 🔴 Critical Financial Rules (7 rules)

#### **RULE-FIN-001: Order Fee Calculation**

- **Type**: Financial Business Rule
- **Location**: `TradeConfig.java:315-324`
- **Description**: Determine transaction fee based on order type
- **Implementation**:
  ```java
  public static BigDecimal getOrderFee(String orderType) {
      if ((orderType.compareToIgnoreCase("BUY") == 0) ||
          (orderType.compareToIgnoreCase("SELL") == 0))
          return new BigDecimal("24.95");
      return new BigDecimal("0.0");
  }
  ```
- **Business Context**: Revenue generation through trading fees
- **Impact**: 🔴 Critical - All trading revenue depends on this rule
- **Modernization Notes**: Must preserve exact fee amounts and logic

---

#### **RULE-FIN-002: Buy Order Total Calculation**

- **Type**: Financial Calculation Rule
- **Location**: `TradeDirect.java:237`
- **Description**: Calculate total cost for buy orders including fees
- **Implementation**:
  ```java
  BigDecimal price = quoteData.getPrice();
  BigDecimal orderFee = orderData.getOrderFee();
  total = (new BigDecimal(quantity).multiply(price)).add(orderFee);
  ```
- **Business Context**: Core purchase transaction calculation affecting all buy orders
- **Impact**: 🔴 Critical - Customer billing and account debiting accuracy
- **Modernization Notes**: BigDecimal precision must be maintained exactly

---

#### **RULE-FIN-003: Sell Order Total Calculation**

- **Type**: Financial Calculation Rule
- **Location**: `TradeDirect.java:349`
- **Description**: Calculate proceeds from sell orders minus fees
- **Implementation**:
  ```java
  BigDecimal price = quoteData.getPrice();
  BigDecimal orderFee = orderData.getOrderFee();
  total = (new BigDecimal(quantity).multiply(price)).subtract(orderFee);
  ```
- **Business Context**: Customer proceeds calculation for all sell orders
- **Impact**: 🔴 Critical - Customer payment and account crediting accuracy
- **Modernization Notes**: BigDecimal precision and fee deduction logic must be preserved

---

#### **RULE-FIN-004: Account Balance Validation**

- **Type**: Financial Control Rule
- **Location**: `TradeDirect.java:239`
- **Description**: Ensure sufficient funds before processing buy orders
- **Implementation**:
  ```java
  // Debit account balance (negative amount)
  creditAccountBalance(conn, accountData, total.negate());
  ```
- **Business Context**: Overdraft prevention and payment validation
- **Impact**: 🔴 Critical - Financial risk management and regulatory compliance
- **Modernization Notes**: Must maintain exact balance checking logic

---

#### **RULE-FIN-005: Financial Precision Standards**

- **Type**: Financial Standards Rule
- **Location**: `FinancialUtils.java:28-30`
- **Description**: All financial calculations use exact precision
- **Implementation**:
  ```java
  public final static int ROUND = BigDecimal.ROUND_HALF_UP;
  public final static int SCALE = 2;
  public final static BigDecimal ZERO = (new BigDecimal(0.00)).setScale(SCALE);
  ```
- **Business Context**: Financial accuracy and regulatory compliance
- **Impact**: 🔴 Critical - Legal and audit requirements
- **Modernization Notes**: Exact rounding and scaling must be preserved

---

#### **RULE-FIN-006: Gain/Loss Calculation**

- **Type**: Financial Analytics Rule
- **Location**: `FinancialUtils.java:34-37`
- **Description**: Calculate portfolio position gains and losses
- **Implementation**:
  ```java
  public static BigDecimal computeGain(BigDecimal currentBalance, BigDecimal openBalance) {
      return currentBalance.subtract(openBalance).setScale(SCALE);
  }
  ```
- **Business Context**: Portfolio performance reporting and tax calculation
- **Impact**: 🔴 Critical - Customer reporting and tax implications
- **Modernization Notes**: Exact calculation method must be maintained

---

#### **RULE-FIN-007: Holdings Total Valuation**

- **Type**: Financial Valuation Rule
- **Location**: `FinancialUtils.java:49-61`
- **Description**: Calculate total value of all portfolio holdings
- **Implementation**:
  ```java
  public static BigDecimal computeHoldingsTotal(Collection<?> holdingDataBeans) {
      BigDecimal holdingsTotal = new BigDecimal(0.0).setScale(SCALE);
      Iterator<?> it = holdingDataBeans.iterator();
      while (it.hasNext()) {
          HoldingDataBean holdingData = (HoldingDataBean) it.next();
          BigDecimal total = holdingData.getPurchasePrice().multiply(new BigDecimal(holdingData.getQuantity()));
          holdingsTotal = holdingsTotal.add(total);
      }
      return holdingsTotal.setScale(SCALE);
  }
  ```
- **Business Context**: Portfolio total value for customer reporting
- **Impact**: 🔴 Critical - Portfolio valuation accuracy
- **Modernization Notes**: Iteration logic and precision handling must be preserved

---

### 🔴 Critical Market Rules (3 rules)

#### **RULE-MKT-001: Penny Stock Recovery**

- **Type**: Market Intervention Rule
- **Location**: `TradeConfig.java:122-132`
- **Description**: Automatic price recovery for penny stocks
- **Implementation**:
  ```java
  public static BigDecimal PENNY_STOCK_PRICE = new BigDecimal(0.01).setScale(2, BigDecimal.ROUND_HALF_UP);
  public static BigDecimal PENNY_STOCK_RECOVERY_MIRACLE_MULTIPLIER = new BigDecimal(600.0).setScale(2, BigDecimal.ROUND_HALF_UP);
  
  // In price update logic:
  if (oldPrice.equals(TradeConfig.PENNY_STOCK_PRICE)) {
      changeFactor = TradeConfig.PENNY_STOCK_RECOVERY_MIRACLE_MULTIPLIER;
  }
  ```
- **Business Context**: Prevents stocks from becoming worthless, maintains trading interest
- **Impact**: 🔴 Critical - Market viability and customer engagement
- **Modernization Notes**: Exact trigger price and multiplier values must be preserved

---

#### **RULE-MKT-002: Stock Price Ceiling**

- **Type**: Market Control Rule  
- **Location**: `TradeConfig.java:139-146`
- **Description**: Automatic stock split when price exceeds maximum
- **Implementation**:
  ```java
  public static BigDecimal MAXIMUM_STOCK_PRICE = new BigDecimal(400).setScale(2, BigDecimal.ROUND_HALF_UP);
  public static BigDecimal MAXIMUM_STOCK_SPLIT_MULTIPLIER = new BigDecimal(0.5).setScale(2, BigDecimal.ROUND_HALF_UP);
  
  // In price update logic:
  if (oldPrice.compareTo(TradeConfig.MAXIMUM_STOCK_PRICE) > 0) {
      changeFactor = TradeConfig.MAXIMUM_STOCK_SPLIT_MULTIPLIER;
  }
  ```
- **Business Context**: Database precision limits and automatic stock management
- **Impact**: 🔴 Critical - Database integrity and system stability
- **Modernization Notes**: Price ceiling and split ratio must be exactly maintained

---

#### **RULE-MKT-003: Quote Price Update Logic**

- **Type**: Market Data Rule
- **Location**: Price update methods in TradeDirect.java
- **Description**: Stock price changes based on random factors with boundaries
- **Implementation**:
  ```java
  public static BigDecimal getRandomPriceChangeFactor() {
      double percentGain = rndFloat(1) * 0.2;  // +/- 20%
      if (random() < .5) percentGain *= -1;
      percentGain += 1;
      BigDecimal percentGainBD = (new BigDecimal(percentGain)).setScale(2, BigDecimal.ROUND_HALF_UP);
      if (percentGainBD.doubleValue() <= 0.0) percentGainBD = ONE;
      return percentGainBD;
  }
  ```
- **Business Context**: Market simulation and price volatility
- **Impact**: 🟠 High - Market dynamics and trading realism
- **Modernization Notes**: Random factor range and boundary logic must be preserved

---

### 🟠 High Priority Workflow Rules (8 rules)

#### **RULE-WFL-001: Order Processing Mode Selection**

- **Type**: Workflow Control Rule
- **Location**: `TradeConfig.java:43-47`
- **Description**: Determine synchronous vs asynchronous order processing
- **Implementation**:
  ```java
  public static final int SYNCH = 0;
  public static final int ASYNCH_2PHASE = 1;
  public static int orderProcessingMode = SYNCH;
  
  // In buy/sell methods:
  if (orderProcessingMode == TradeConfig.SYNCH)
      completeOrder(conn, orderData.getOrderID());
  else if (orderProcessingMode == TradeConfig.ASYNCH_2PHASE)
      queueOrder(orderData.getOrderID(), true);
  ```
- **Business Context**: System performance optimization and transaction integrity
- **Impact**: 🟠 High - System scalability and user experience
- **Modernization Notes**: JMS integration patterns must be preserved for async mode

---

#### **RULE-WFL-002: Order Status Lifecycle**

- **Type**: Workflow State Rule
- **Location**: `OrderDataBean.java:67`
- **Description**: Order progresses through defined states
- **Implementation**:
  ```java
  @Column(name = "ORDERSTATUS")
  private String orderStatus; // "open", "processing", "completed", "closed", "cancelled"
  
  // Status transitions managed in complete/cancel methods
  ```
- **Business Context**: Order tracking and customer notification
- **Impact**: 🟠 High - Customer service and order management
- **Modernization Notes**: State machine transitions must be exactly preserved

---

#### **RULE-WFL-003: Transaction Rollback Logic**

- **Type**: Error Recovery Rule
- **Location**: `TradeDirect.java:264-269`
- **Description**: Automatic rollback and order cancellation on errors
- **Implementation**:
  ```java
  } catch (Exception e) {
      Log.error("TradeDirect:buy error - rolling back", e);
      if (getInGlobalTxn())
          txn.rollback();
      else
          rollBack(conn, e);
  }
  ```
- **Business Context**: Data consistency and error recovery
- **Impact**: 🔴 Critical - System integrity and customer protection
- **Modernization Notes**: Error handling and rollback mechanisms must be preserved

---

#### **RULE-WFL-004: JMS Queue Order Processing**

- **Type**: Messaging Workflow Rule
- **Location**: MDB processing in DTBroker3MDB.java
- **Description**: Asynchronous order completion via message-driven beans
- **Implementation**:
  ```java
  // Queue order for async processing
  public void queueOrder(Integer orderID, boolean twoPhase) throws Exception {
      // JMS message creation and queue submission
  }
  ```
- **Business Context**: High-volume order processing and system scalability
- **Impact**: 🟠 High - Performance and throughput
- **Modernization Notes**: JMS patterns and MDB processing must be maintained

---

#### **RULE-WFL-005: Global Transaction Management**

- **Type**: Transaction Control Rule
- **Location**: `TradeDirect.java:213-221`
- **Description**: Two-phase commit for distributed transactions
- **Implementation**:
  ```java
  if (!inSession && orderProcessingMode == TradeConfig.ASYNCH_2PHASE) {
      txn = (javax.transaction.UserTransaction) context.lookup("java:comp/UserTransaction");
      txn.begin();
      setInGlobalTxn(true);
  }
  ```
- **Business Context**: Distributed transaction integrity across systems
- **Impact**: 🔴 Critical - Data consistency across multiple resources
- **Modernization Notes**: Transaction boundaries and commit logic must be preserved

---

#### **RULE-WFL-006: Order Completion Logic**

- **Type**: Business Process Rule
- **Location**: `TradeDirect.java:1157-1246`
- **Description**: Complete order processing with holdings and balance updates
- **Implementation**:
  ```java
  private OrderDataBean completeOrder(Connection conn, Integer orderID) throws Exception {
      // For buy orders: create holding, update account
      // For sell orders: remove holding, credit account
      // Update order status to completed
  }
  ```
- **Business Context**: Final settlement of trading transactions
- **Impact**: 🔴 Critical - Transaction completion and customer account accuracy
- **Modernization Notes**: Exact sequence of operations must be maintained

---

#### **RULE-WFL-007: Order Cancellation Logic**

- **Type**: Error Recovery Rule
- **Location**: Order cancellation methods
- **Description**: Cancel orders and reverse account impacts
- **Implementation**:
  ```java
  public void cancelOrder(Connection conn, Integer orderID) {
      // Reverse account balance changes
      // Update order status to cancelled
  }
  ```
- **Business Context**: Error recovery and customer protection
- **Impact**: 🟠 High - Customer service and data integrity
- **Modernization Notes**: Compensation logic must be exactly preserved

---

#### **RULE-WFL-008: Session Management**

- **Type**: User Session Rule
- **Location**: Session handling throughout application
- **Description**: Track user sessions and authentication state
- **Business Context**: Security and user experience
- **Impact**: 🟠 High - Security and personalization
- **Modernization Notes**: Session state management patterns must be maintained

---

### 🟡 Medium Priority Configuration Rules (7 rules)

#### **RULE-CFG-001: Runtime Mode Selection**

- **Type**: Configuration Rule
- **Location**: `TradeConfig.java:37-41`
- **Description**: Select application runtime architecture mode
- **Implementation**:
  ```java
  public static final int EJB3 = 0;      // Full EJB3
  public static final int DIRECT = 1;     // Direct JDBC
  public static final int SESSION3 = 2;   // Session to Direct
  public static int runTimeMode = EJB3;
  ```
- **Business Context**: System architecture and performance tuning
- **Impact**: 🟡 Medium - System architecture flexibility
- **Modernization Notes**: Runtime mode selection mechanism should be preserved

---

#### **RULE-CFG-002: Scenario Mix Configuration**

- **Type**: Load Testing Rule
- **Location**: `TradeConfig.java:165-170`
- **Description**: Define user behavior patterns for load testing
- **Implementation**:
  ```java
  private static int scenarioMixes[][] = {
      { 20, 40, 0, 4, 2, 10, 12, 4, 4, 4 }, // STANDARD
      { 20, 40, 0, 4, 2, 7, 7, 7, 7, 6 }    // High Volume
  };
  ```
- **Business Context**: Performance testing and system validation
- **Impact**: 🟡 Medium - Testing and benchmarking capability
- **Modernization Notes**: Preserve for performance testing compatibility

---

#### **RULE-CFG-003: Database Configuration**

- **Type**: Data Access Rule
- **Location**: `TradeConfig.java:80-86`
- **Description**: Database connection and datasource configuration
- **Implementation**:
  ```java
  public static String DATASOURCE = "java:comp/env/jdbc/TradeDataSource";
  public static int KEYBLOCKSIZE = 1000;
  ```
- **Business Context**: Database connectivity and performance
- **Impact**: 🟡 Medium - Database integration
- **Modernization Notes**: Connection patterns may need updating for new platforms

---

#### **RULE-CFG-004: User Account Initialization**

- **Type**: Account Setup Rule
- **Location**: `TradeConfig.java:352-353`
- **Description**: Initialize new user accounts with standard balance
- **Implementation**:
  ```java
  public static String rndBalance() {
      return "1000000";  // Give all new users a cool million
  }
  ```
- **Business Context**: Demo account setup and user onboarding
- **Impact**: 🟡 Medium - User experience and demo functionality
- **Modernization Notes**: Configurable parameter for different deployment environments

---

#### **RULE-CFG-005: Market Data Limits**

- **Type**: Data Boundary Rule
- **Location**: `TradeConfig.java:74-75`
- **Description**: Set maximum users and quotes for system scaling
- **Implementation**:
  ```java
  private static int MAX_USERS = 15000;
  private static int MAX_QUOTES = 10000;
  ```
- **Business Context**: System capacity planning and resource limits
- **Impact**: 🟡 Medium - System scalability
- **Modernization Notes**: Should be made configurable for different environments

---

#### **RULE-CFG-006: Web Interface Selection**

- **Type**: UI Configuration Rule
- **Location**: `TradeConfig.java:60-63`
- **Description**: Choose between JSP interface variants
- **Implementation**:
  ```java
  public static final int JSP = 0;
  public static final int JSP_Images = 1;
  public static int webInterface = JSP;
  ```
- **Business Context**: User interface customization
- **Impact**: 🟡 Medium - User experience options
- **Modernization Notes**: May be replaced with modern UI framework selection

---

#### **RULE-CFG-007: Caching Configuration**

- **Type**: Performance Rule
- **Location**: `TradeConfig.java:66-71`
- **Description**: Configure application caching strategy
- **Implementation**:
  ```java
  public static final int DISTRIBUTEDMAP = 0;
  public static final int COMMAND_CACHING = 1;
  public static final int NO_CACHING = 2;
  public static int cachingType = NO_CACHING;
  ```
- **Business Context**: Performance optimization and scalability
- **Impact**: 🟡 Medium - System performance
- **Modernization Notes**: Caching strategy may need updating for modern platforms

---

## Business Rule Interdependencies

```mermaid
graph TB
    subgraph "Financial Rules"
        FIN001[Order Fee Calculation]
        FIN002[Buy Total Calculation]
        FIN003[Sell Total Calculation]
        FIN004[Balance Validation]
    end
    
    subgraph "Market Rules"
        MKT001[Penny Stock Recovery]
        MKT002[Price Ceiling]
        MKT003[Quote Updates]
    end
    
    subgraph "Workflow Rules"
        WFL001[Processing Mode]
        WFL002[Order Status]
        WFL003[Transaction Rollback]
        WFL006[Order Completion]
    end
    
    FIN001 --> FIN002
    FIN001 --> FIN003
    FIN002 --> FIN004
    FIN003 --> FIN004
    MKT003 --> FIN002
    MKT003 --> FIN003
    WFL001 --> WFL006
    WFL002 --> WFL006
    WFL003 --> WFL006
```

## Modernization Preservation Checklist

### 🔴 **Must Preserve Exactly** (Critical Business Logic)
- [ ] All BigDecimal calculations with exact precision and rounding
- [ ] Order fee structure ($24.95 for trades, $0.00 for cash)
- [ ] Buy/sell total calculation formulas
- [ ] Account balance validation logic
- [ ] Penny stock recovery mechanism ($0.01 → $6.00)
- [ ] Stock price ceiling enforcement ($400 → stock split)
- [ ] Transaction rollback and error handling
- [ ] Order status lifecycle state machine

### 🟠 **Preserve Logic, Allow Implementation Updates** (High Priority)
- [ ] JMS message processing patterns (can modernize messaging platform)
- [ ] Two-phase commit transaction boundaries
- [ ] Order completion workflow sequences
- [ ] Holdings calculation and portfolio valuation
- [ ] Market data update mechanisms
- [ ] User session management patterns

### 🟡 **Configurable/Updatable** (Medium Priority)
- [ ] Runtime mode selection (can modernize architecture choices)
- [ ] Database connection configurations
- [ ] User interface selection (can replace with modern UI)
- [ ] Caching strategies (can implement modern caching)
- [ ] System capacity limits (should be environment-specific)
- [ ] Scenario mix testing parameters

## Implementation Notes

### **Database Schema Dependencies**
- Order fee calculations depend on order type field constraints
- Account balance precision requires DECIMAL(14,2) or equivalent  
- Order status transitions require specific varchar constraints
- Quote price boundaries affect allowable price ranges in database

### **Integration Preservation Requirements**
- JMS queue naming and message formats for async processing
- Transaction manager integration for distributed transactions
- Database connection pooling and transaction isolation levels
- Error handling and logging integration points

### **Testing Requirements**
Each business rule requires:
1. **Unit Tests**: Individual rule logic validation
2. **Integration Tests**: Cross-rule interaction verification  
3. **Boundary Tests**: Edge case and limit testing
4. **Error Tests**: Exception handling and rollback verification
5. **Performance Tests**: Load testing with business rule constraints

---

**This catalog provides the definitive reference for preserving business logic during daytrader modernization efforts. Each rule must be validated against this specification during any code changes or platform migrations.**